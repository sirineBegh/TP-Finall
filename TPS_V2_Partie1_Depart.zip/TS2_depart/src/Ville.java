// Classe dérivée Ville
class Ville extends Pays {
    private String nomVille;

    // Constructeur
    public Ville(String nom, int population, String nomVille) {
        super(nom, population);
        this.nomVille = nomVille;
    }

    // Getter et setter

   //TODO 3
}