// Classe dérivée
// TODO 1.1
