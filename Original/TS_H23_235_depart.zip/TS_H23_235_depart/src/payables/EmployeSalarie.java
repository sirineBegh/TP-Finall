package payables;


public class EmployeSalarie extends Employe {
    //
    // TODO 01 Ajoutez tout le code nécessaire pour compléter la classe en vous basant sur
    //         le diagramme UML ainsi que la gestion des erreurs possibles si nécessaire.
	//

	@Override
	public double getMontantPaiement() {
		return getSalaireHebdomadaire();
	}

	@Override
	public String toString() {
		return String.format("%s: %s%n%s: %,.2f",
				getCategorieString(), super.toString(), "salaire hebdomadaire", getSalaireHebdomadaire());
	}

	public String toStringAffichage() {
			String info = super.toStringAffichage();
			info += " Salaire [" + this.getSalaireHebdomadaire()  + "]";
			return info;
	}
}
