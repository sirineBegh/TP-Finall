package payables;

/**
 * Représente chacun de types de Payable supportés.
 */
public enum Categorie {
    Facture,
    EmployeHoraire,
    EmployeHoraireAvecCommission,
    EmployeSalarie,
    EmployeSalarieAvecCommission
}
