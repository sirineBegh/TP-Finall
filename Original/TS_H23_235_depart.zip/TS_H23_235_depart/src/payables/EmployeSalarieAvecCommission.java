//
// TODO 02 Ajoutez tout le code nécessaire pour coder la classe au complet en vous basant sur
//         le diagramme UML ainsi que la gestion des erreurs possibles si nécessaire.
//
