package payables;

/**
 * Interface pour supporter le paiement de commissions.
 */
public interface Commission {
    double getTauxCommission();
    double getVentesBrutes();
    double getMontantCommission(double ventesBrutes);
}
