package exceptions;

/**
 * Exception générée quand le nombre de jours d'échéance passe sous zéro.
 */
public class ExceptionEcheanceInsuffisante extends Exception {
    public ExceptionEcheanceInsuffisante(int jours) {
        super("Enlever " + jours + " d'échéance mènerait à une échéance négative.");
    }
}
