package exceptions;
//
// TODO 08 Ajoutez le code nécessaire pour créer l'exception générée
//         quand on essaie de référer è un payable inexistant
//
