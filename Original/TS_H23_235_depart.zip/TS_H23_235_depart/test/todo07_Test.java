import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import exceptions.*;
import inventaire.GestionnaireInventaire;
import payables.Facture;
import payables.Payable;

public class todo07_Test extends TestBase {
    private GestionnaireInventaire gI;
    private Facture facture;

    @Before
    public void setUp()  {
        gI = new GestionnaireInventaire();
        facture = new Facture(23,"UH77TY","scie ronde",2,300,"premium");
    }

    @Test
    public void testAjouterPayable() throws ExceptionPayableExisteDeja {
        int avant = gI.getTableauPayables().length;
        gI.ajouterPayable(facture);
        int apres = gI.getTableauPayables().length;
        assertEquals(avant,apres-1);
    }

    @Test
    public void testRetirerPayable() throws ExceptionPayableIntrouvable, ExceptionPayableExisteDeja {
        gI.ajouterPayable(facture);
        int avant = gI.getTableauPayables().length;
        gI.retirerPayable(23);
        int apres = gI.getTableauPayables().length;
        assertEquals(avant-1,apres);
    }

    @Test
    public void testAugmenterEcheance() throws ExceptionPayableIntrouvable{
        Payable p = facture;
        p.augmenterEcheance(5);
        assertEquals(p.getEcheanceJours(),5);
    }

    @Test
    public void testDimimuerEcheance() throws ExceptionPayableIntrouvable, ExceptionEcheanceInsuffisante {
        Payable p = facture;
        p.augmenterEcheance(10);
        p.diminuerEcheance(5);
        assertEquals(p.getEcheanceJours(),5);
    }

    @Test
    public void testExceptions() throws ExceptionPayableExisteDeja, ExceptionEcheanceInsuffisante, ExceptionPayableIntrouvable{
        gI.ajouterPayable(facture);
        assertThrows(ExceptionPayableExisteDeja.class, () -> {
            gI.ajouterPayable(facture);
        });
        assertThrows(ExceptionPayableIntrouvable.class, () -> {
            gI.retirerPayable(123);
        });
        assertThrows(ExceptionEcheanceInsuffisante.class, () -> {
            facture.diminuerEcheance(100);
        });
    }
}