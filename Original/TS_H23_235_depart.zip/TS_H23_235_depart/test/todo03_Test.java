import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import payables.EmployeHoraire;

public class todo03_Test extends TestBase {
    private EmployeHoraire eh;

    @Before
    public void setUp()  {
        eh = new EmployeHoraire(99,"Richard", "837283828",10,15,"moyen");
    }

    @Test
    public void testDivers() {
        assertEquals(eh.getMontantPaiement(), 15 * 10, 0.001);
        eh.setHeuresTravaillees(45);
        assertEquals(eh.getMontantPaiement(), 40 * 10 + 5 * 1.5 * 10, 0.001);
        assertTrue(distance(eh.toString(), "EmployeHoraire: Richard\nnuméro d'assurance sociale: 837283828\ntaux horaire: 10,00; heures travaillées: 45,00")  < 0.1);
        assertTrue(distance(eh.toStringAffichage(), "ID [ 99] Catégorie [           EmployeHoraire] Mémo [          moyen] Échéance [  0] Paiement [    475,00] Nom complet [             Richard] NAS [837283828] Salaire [10.0] Heures [45.0]") < 0.1);
    }
}