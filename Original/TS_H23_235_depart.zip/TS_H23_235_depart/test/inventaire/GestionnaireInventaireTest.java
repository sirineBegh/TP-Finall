package inventaire;

import exceptions.ExceptionEcheanceInsuffisante;
import exceptions.ExceptionPayableExisteDeja;
import exceptions.ExceptionPayableIntrouvable;
import org.junit.Before;
import org.junit.Test;
import payables.*;

import static org.junit.Assert.*;

public class GestionnaireInventaireTest {
    GestionnaireInventaire gi;
    Payable p1, p2, p3, p4, p5;

    @Before
    public void setUp() throws Exception {
        p1 = new EmployeSalarie(10, "Marie Renaud", "246864246", 5000, "Bonne employée");
        p2 = new EmployeHoraire(11, "Kevin Bouchard", "123321123", 25.50, 35, "Assidu");
        p3 = new EmployeSalarieAvecCommission(12, "Aline Brullemans", "123327832", 4000, 0.1, 15000, "Peu motivée");
        p4 = new EmployeHoraireAvecCommission(13, "Alan Walsh", "973813265", 15, 32.5,0.15, 40000, "Du potentiel");
        p5 = new Facture(14, "34X53", "Tournevis", 34, 23, "Gros vendeur");

        gi = new GestionnaireInventaire();
        gi.ajouterPayable(p1);
        gi.ajouterPayable(p2);
        gi.ajouterPayable(p3);
        gi.ajouterPayable(p4);
        gi.ajouterPayable(p5);
    }

    @Test
    public void getPayable() throws ExceptionPayableIntrouvable {
        assertSame(p1, gi.getPayable(10));
        assertSame(p3, gi.getPayable(12));
        assertSame(p5, gi.getPayable(14));
    }

    @Test(expected = ExceptionPayableIntrouvable.class)
    public void getPayableInvalide() throws ExceptionPayableIntrouvable {
        gi.getPayable(1);
    }

    @Test
    public void ajouterPayable() {
        Payable[] attendu = {p5, p4, p3, p2, p1};
        assertArrayEquals(attendu, gi.getTableauPayables());
    }

    @Test(expected = ExceptionPayableExisteDeja.class)
    public void ajouterPayableExistant() throws ExceptionPayableExisteDeja {
        gi.ajouterPayable(p2);
    }

    @Test
    public void retirerPayable() throws ExceptionPayableIntrouvable {
        assertArrayEquals(new Payable[] {p5, p4, p3, p2, p1}, gi.getTableauPayables());
        gi.retirerPayable(10);
        assertArrayEquals(new Payable[] {p5, p4, p3, p2}, gi.getTableauPayables());
        gi.retirerPayable(12);
        assertArrayEquals(new Payable[] {p5, p4, p2}, gi.getTableauPayables());
        gi.retirerPayable(14);
        assertArrayEquals(new Payable[] {p4, p2}, gi.getTableauPayables());
    }

    @Test(expected = ExceptionPayableIntrouvable.class)
    public void enleverInvalide() throws ExceptionPayableIntrouvable {
        gi.retirerPayable(1);
    }

    @Test
    public void augmenterEcheancePayable() throws ExceptionPayableIntrouvable {
        gi.augmenterEcheancePayable(10, 5);
        assertEquals(5, p1.getEcheanceJours());
        gi.augmenterEcheancePayable(10, 3);
        assertEquals(8, p1.getEcheanceJours());
        gi.augmenterEcheancePayable(10, 0);
        assertEquals(8, p1.getEcheanceJours());
    }

    @Test(expected = ExceptionPayableIntrouvable.class)
    public void augmenterEcheanceIntrouvable() throws ExceptionPayableIntrouvable {
        gi.augmenterEcheancePayable(9, 1);
    }

    @Test
    public void diminuerEcheancePayable() throws ExceptionPayableIntrouvable, ExceptionEcheanceInsuffisante {
        gi.augmenterEcheancePayable(10, 5);
        assertEquals(5, p1.getEcheanceJours());
        gi.diminuerEcheancePayable(10, 3);
        assertEquals(2, p1.getEcheanceJours());
        gi.diminuerEcheancePayable(10, 2);
        assertEquals(0, p1.getEcheanceJours());
    }

    @Test(expected = ExceptionPayableIntrouvable.class)
    public void diminuerEcheanceIntrouvable() throws ExceptionPayableIntrouvable, ExceptionEcheanceInsuffisante {
        gi.diminuerEcheancePayable(9, 1);
    }

    @Test(expected = ExceptionEcheanceInsuffisante.class)
    public void diminuerEcheanceInvalide() throws ExceptionPayableIntrouvable, ExceptionEcheanceInsuffisante {
        gi.diminuerEcheancePayable(10, 1);
    }
}