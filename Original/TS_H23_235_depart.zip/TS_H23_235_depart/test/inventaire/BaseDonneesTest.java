package inventaire;

import exceptions.ExceptionPayableExisteDeja;
import exceptions.ExceptionPayableIntrouvable;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import payables.*;

public class BaseDonneesTest {
    BaseDonnees bd;
    Payable p1, p2, p3, p4, p5;
    @Before
    public void setUp() throws Exception {
        p1 = new EmployeSalarie(10, "Marie Renaud", "246864246", 5000, "Bonne employée");
        p2 = new EmployeHoraire(11, "Kevin Bouchard", "123321123", 25.50, 35, "Assidu");
        p3 = new EmployeSalarieAvecCommission(12, "Aline Brullemans", "123327832", 4000, 0.1, 15000, "Peu motivée");
        p4 = new EmployeHoraireAvecCommission(13, "Alan Walsh", "973813265", 15, 32.5,0.15, 40000, "Du potentiel");
        p5 = new Facture(14, "34X53", "Tournevis", 34, 23, "Gros vendeur");

        bd = new BaseDonnees();
        bd.inserer(p1);
        bd.inserer(p2);
        bd.inserer(p3);
        bd.inserer(p4);
        bd.inserer(p5);
    }

    @Test
    public void trouverParID() {
        assertNull(bd.trouverParID(9));
        assertSame(p1, bd.trouverParID(10));
        assertSame(p3, bd.trouverParID(12));
        assertSame(p5, bd.trouverParID(14));
        assertNull(bd.trouverParID(15));
    }

    @Test
    public void inserer() {
        Payable[] attendu = {p5, p4, p3, p2, p1}; // Pourquoi les payables sont en ordre inverse?
        assertArrayEquals(attendu, bd.getTableauPayables());
    }

    @Test(expected = ExceptionPayableExisteDeja.class)
    public void insererDuplique() throws ExceptionPayableExisteDeja {
        bd.inserer(p2);
    }

    @Test
    public void enlever() throws ExceptionPayableIntrouvable {
        assertArrayEquals(new Payable[] {p5, p4, p3, p2, p1}, bd.getTableauPayables());
        bd.enlever(10);
        assertArrayEquals(new Payable[] {p5, p4, p3, p2}, bd.getTableauPayables());
        bd.enlever(12);
        assertArrayEquals(new Payable[] {p5, p4, p2}, bd.getTableauPayables());
        bd.enlever(14);
        assertArrayEquals(new Payable[] {p4, p2}, bd.getTableauPayables());
    }

    @Test(expected = ExceptionPayableIntrouvable.class)
    public void enleverInvalide() throws ExceptionPayableIntrouvable {
        bd.enlever(1);
    }

    @Test(expected = ExceptionPayableIntrouvable.class)
    public void enleverVide() throws ExceptionPayableIntrouvable {
        bd = new BaseDonnees();
        bd.enlever(10);
    }
}