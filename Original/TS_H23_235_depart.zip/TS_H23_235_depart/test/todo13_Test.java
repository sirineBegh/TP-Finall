import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

// Vous êtes responsable de tester le comportement graphique de creerBoutonEffacage()
// Pour le moment, ce test échoue;
// Quand vous aurez complété et validé cette fonctionnalité, retirez l'instruction fail()
public class todo13_Test {
    @Test @Ignore
    public void testRien() {
        fail("creerBoutonEffacage non testé encore");
    }
}