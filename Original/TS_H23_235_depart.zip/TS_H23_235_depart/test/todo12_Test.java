import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

// Vous êtes responsable de tester le comportement graphique de creerBoutonEdition()
// Pour le moment, ce test échoue;
// Quand vous aurez complété et validé cette fonctionnalité, retirez l'instruction fail()
public class todo12_Test {
    @Test @Ignore
    public void testRien() {
        fail("creerBoutonEdition non testé encore");
    }
}