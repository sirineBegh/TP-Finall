import inventaire.GestionnaireInventaire;
import payables.EmployeSalarieAvecCommission;
import payables.Facture;
import payables.Payable;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class todo15_Test {
    private GestionnaireInventaire gI;
    private String fichier;
    private Payable[] payables;

    @Before
    public void setUp()  {
        Payable p1 = new Facture(67,"uy90","madrier",75,20,"érable");
        Payable p2 = new EmployeSalarieAvecCommission(32,"Peter","983463848",2000,0.2,40000,"travaillant");
        payables = new Payable[2];
        payables[0] = p1;
        payables[1] = p2;
        fichier = "payablesTest.out";
        gI = new GestionnaireInventaire();
    }

    @Test
    public void testEcrireInventaire() throws Exception {
        Main.ecrireInventaire(fichier,payables);
        Main.lireInventaire(fichier,gI);
        assertEquals(gI.getTableauPayables().length,2);
        assertEquals(gI.getPayable(32).getMemo().strip(), "travaillant");
    }
}