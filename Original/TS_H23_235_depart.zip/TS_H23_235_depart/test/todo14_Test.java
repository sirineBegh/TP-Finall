import inventaire.GestionnaireInventaire;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class todo14_Test {
    private GestionnaireInventaire gI;
    private String fichier;

    @Before
    public void setUp()  {
        fichier = "payables.in";
        gI = new GestionnaireInventaire();
    }

    @Test
    public void testLireInventaire() throws Exception {
        Main.lireInventaire(fichier,gI);
        assertEquals(gI.getTableauPayables().length,5);
        assertEquals(gI.getPayable(13).getMemo().strip(), "Du potentiel");
    }

    @Test
    public void testException() {
        assertThrows(Exception.class, () -> {
            Main.lireInventaire(fichier + "xtra",gI);
        });
    }
}