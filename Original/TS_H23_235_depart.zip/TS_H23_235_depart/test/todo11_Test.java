import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

// Vous êtes responsable de tester le comportement graphique de creerBoutonRetrait()
// Pour le moment, ce test échoue;
// Quand vous aurez complété et validé cette fonctionnalité, retirez l'instruction fail()
public class todo11_Test {
    @Test @Ignore
    public void testRien() {
        fail("creerBoutonRetrait non testé encore");
    }
}