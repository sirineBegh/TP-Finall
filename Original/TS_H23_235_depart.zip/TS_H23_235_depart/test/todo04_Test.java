import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import payables.EmployeHoraireAvecCommission;

public class todo04_Test extends TestBase {
    private EmployeHoraireAvecCommission ehac;

    @Before
    public void setUp()  {
        ehac = new EmployeHoraireAvecCommission(99,"Pierre", "123456789",5000,35,0.1, 35000,"excellent");
    }

    @Test
    public void testDivers() {
        ehac.setTauxCommission(0.2);
        assertEquals(ehac.getTauxCommission(), 0.2, 0.001);
        ehac.setVentesBrutes(37500);
        assertEquals(ehac.getVentesBrutes(), 37500, 0.001);
        assertEquals(ehac.getMontantCommission(37500), 0.2 * 37500, 0.001);
        assertEquals(ehac.getMontantPaiement(), 0.2 * 37500 + 5000 * 35, 0.001);
    }

    @Test
    public void testTauxInvalide() {
        assertThrows(IllegalArgumentException.class, () -> {
            ehac.setTauxCommission(-0.2);
        });
    }

    @Test
    public void testVentesInvalides() {
        assertThrows(IllegalArgumentException.class, () -> {
            ehac.setVentesBrutes(-37500);
        });
    }
}