public class TestBase {
    public static float distance(String a, String b) {
        int[] couts = new int[b.length() + 1];
        for (int j = 0; j < couts.length; j++)
            couts[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            couts[0] = i;
            int nw = i - 1;
            for (int j = 1; j <= b.length(); j++) {
                int cj = Math.min(1 + Math.min(couts[j], couts[j - 1]),
                        a.charAt(i - 1) == b.charAt(j - 1) ? nw : nw + 1);
                nw = couts[j];
                couts[j] = cj;
            }
        }
        float plusPetite = Math.min(a.length(), b.length());
        return couts[b.length()]/plusPetite;
    }
}
