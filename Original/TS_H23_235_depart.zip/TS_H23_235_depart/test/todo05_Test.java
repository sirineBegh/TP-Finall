import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import payables.Facture;

public class todo05_Test extends TestBase {
    private Facture facture;

    @Before
    public void setUp()  {
        facture = new Facture(99,"Vc45XC", "Marteau",10,12,"excellent");
    }

    @Test
    public void testDivers() {
        facture.setPrixParItem(9);
        assertEquals(facture.getPrixParItem(), 9, 0.001);
        assertEquals(facture.getMontantPaiement(), 10 * 9, 0.001);
        assertTrue(distance(facture.toString(), "Facture:\nnuméro de la pièce: Vc45XC (Marteau)\nquantité: 10\nprix par item: 9,00")  < 0.1);
        assertTrue(distance(facture.toStringAffichage(), "ID [ 99] Catégorie [                  Facture] Mémo [      excellent] Échéance [  0] Paiement [     90,00] Code [Vc45XC] Description [Marteau] Quantité [10] Prix [9.0]") < 0.1);
    }

    @Test
    public void testPrixInvalide() {
        assertThrows(IllegalArgumentException.class, () -> {
            facture.setPrixParItem(-9);
        });
    }
}