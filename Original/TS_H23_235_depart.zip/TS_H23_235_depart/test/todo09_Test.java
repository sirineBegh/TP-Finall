import org.junit.Test;
import static org.junit.Assert.*;

// Cette exception est déjà testée dans d'autres tests.
public class todo09_Test {
    @Test
    public void testRien() {
        assertTrue(true);
    }
}