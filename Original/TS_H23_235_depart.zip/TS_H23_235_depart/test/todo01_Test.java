import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import payables.EmployeSalarie;

public class todo01_Test extends TestBase {
    private EmployeSalarie es;

    @Before
    public void setUp()  {
        es = new EmployeSalarie(99,"Pierre", "123456789",5000,"excellent");
    }

    @Test
    public void testEmployeSalarie() {
        assertEquals(es.getID(), 99);
        assertEquals(es.getNomComplet(), "Pierre");
        assertEquals(es.getNumeroAssuranceSociale(), "123456789");
        assertEquals(es.getSalaireHebdomadaire(), 5000, 0.001);
        assertEquals(es.getMemo(), "excellent");
    }

    @Test
    public void testSalaireHebdomadaire() {
        es.setSalaireHebdomadaire(3000);
        assertEquals(es.getSalaireHebdomadaire(), 3000, 0.001);

    }
}