import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import payables.EmployeSalarieAvecCommission;

public class todo02_Test extends TestBase {
    private EmployeSalarieAvecCommission esac;

    @Before
    public void setUp()  {
        esac = new EmployeSalarieAvecCommission(99,"Pierre", "123456789",5000,0.2,40000,"excellent");
    }

    @Test
    public void testEmployeSalarieAvecCommission() {
        assertEquals(esac.getID(), 99);
        assertEquals(esac.getNomComplet(), "Pierre");
        assertEquals(esac.getNumeroAssuranceSociale(), "123456789");
        assertEquals(esac.getSalaireHebdomadaire(), 5000, 0.001);
        assertEquals(esac.getTauxCommission(), 0.2, 0.001);
        assertEquals(esac.getVentesBrutes(), 40000, 0.001);
        assertEquals(esac.getMemo(), "excellent");
    }

    @Test
    public void testAutresGetterSetter() {
        esac.setEcheanceJours(10);
        assertEquals(esac.getEcheanceJours(), 10);
        esac.setMemo("parfait");
        assertEquals(esac.getMemo(), "parfait");
        assertEquals(esac.getCategorieString(), "EmployeSalarieAvecCommission");
        assertEquals(esac.getMontantPaiement(), 5000 + 0.2 * 40000, 0.001);
        esac.setSalaireHebdomadaire(3000);
        assertEquals(esac.getSalaireHebdomadaire(), 3000, 0.001);
        esac.setTauxCommission(0.15);
        assertEquals(esac.getTauxCommission(), 0.15, 0.001);
        esac.setVentesBrutes(25000);
        assertEquals(esac.getVentesBrutes(),25000, 0.001);
        assertEquals(esac.getMontantCommission(25000), 0.15 * 25000, 0.001);
    }

    @Test
    public void testAutresMethodes() {
        esac.augmenterEcheance(5);
        esac.augmenterEcheance(5);
        assertEquals(esac.getEcheanceJours(), 10);
        assertTrue(distance(esac.toString(), "EmployeSalarieAvecCommission: Pierre \nnuméro d'assurance sociale: 123456789\nsalaire hebdomadaire: 5 000,00; taux de commission: 0,20")  < 0.01);
        assertTrue(distance(esac.toStringSauvegarde(), "ID [ 99] Nom complet [              Pierre] NAS [123456789] Salaire [5000,00] Taux Commission [0,20] Ventes [  40000,00] Mémo [      excellent] Catégorie [EmployeSalarieAvecCommission]") < 0.01);
        assertTrue(distance(esac.toStringAffichage(), "ID [ 99] Catégorie [EmployeSalarieAvecCommission] Mémo [      excellent] Échéance [ 10] Paiement [  13000,00] Nom complet [              Pierre] NAS [123456789] Salaire [5000.0] Commission [0.2] Ventes [40000.0]") < 0.01);
    }
}