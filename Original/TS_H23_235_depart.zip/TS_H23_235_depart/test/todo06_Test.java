import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import exceptions.ExceptionPayableExisteDeja;
import inventaire.BaseDonnees;
import payables.Facture;
import payables.Payable;

public class todo06_Test extends TestBase {
    private BaseDonnees bD;
    private Facture facture;

    @Before
    public void setUp()  {
        facture = new Facture(22,"j8u6","tournevis", 20,5,"utile");
        bD = new BaseDonnees();
    }

    @Test
    public void testDivers() throws ExceptionPayableExisteDeja {
        assertArrayEquals(bD.getTableauPayables(), new Payable[]{});
        bD.inserer(facture);
        assertArrayEquals(bD.getTableauPayables(), new Payable[]{facture});
    }
}