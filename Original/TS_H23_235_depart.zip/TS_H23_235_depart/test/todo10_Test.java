import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

// Vous êtes responsables de tester le comportement graphique de creerBoutonAjout()
// Pour le moment, ce test échoue;
// Quand vous aurez complété et validé cette fonctionnalité, retirez l'instruction fail()
public class todo10_Test {
    @Test @Ignore
    public void testRien() {
        fail("creerBoutonAjout non testé encore");
    }
}