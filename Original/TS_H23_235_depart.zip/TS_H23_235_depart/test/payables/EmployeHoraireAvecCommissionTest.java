package payables;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class EmployeHoraireAvecCommissionTest {
    EmployeHoraireAvecCommission ehc;

    @Before
    public void setUp() throws Exception {
        ehc = new EmployeHoraireAvecCommission(13, "Alan Walsh", "973813265", 15, 32.5,0.15, 40000, "Du potentiel");
    }

    @Test
    public void setTauxCommission() {
        assertEquals(0.15, ehc.getTauxCommission(), 0.001);
        ehc.setTauxCommission(0.20);
        assertEquals(0.20, ehc.getTauxCommission(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setTauxCommissionMinimum() {
        ehc.setTauxCommission(0.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setTauxCommissionMaximum() {
        ehc.setTauxCommission(1.0);
    }

    @Test
    public void setVentesBrutes() {
        assertEquals(40000, ehc.getVentesBrutes(), 0.001);
        ehc.setVentesBrutes(10000);
        assertEquals(10000, ehc.getVentesBrutes(), 0.001);
        ehc.setVentesBrutes(0);
        assertEquals(0, ehc.getVentesBrutes(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setVentesBrutesInvalide() {
        ehc.setVentesBrutes(-2000);
    }

    @Test
    public void getMontantCommission() {
        assertEquals(0.15 * 12000, ehc.getMontantCommission(12000), 0.001);
    }

    @Test
    public void getMontantPaiement() {
        assertEquals(15*32.5 + 0.15*40000, ehc.getMontantPaiement(), 0.001);
        ehc.setHeuresTravaillees(50.0);
        assertEquals(15*40.0 + 15*1.5*10 + 0.15*40000, ehc.getMontantPaiement(), 0.001);
        ehc.setHeuresTravaillees(0);
        assertEquals(0.15*40000, ehc.getMontantPaiement(), 0.001);
        ehc.setVentesBrutes(0);
        assertEquals(0.0, ehc.getMontantPaiement(), 0.001);
    }

    @Test
    public void getCategorieString() {
        assertEquals("EmployeHoraireAvecCommission", ehc.getCategorieString());
    }

    @Test
    public void toStringAffichage() {
        assertEquals("ID [ 13] Catégorie [EmployeHoraireAvecCommission] Mémo [   Du potentiel] Échéance [  0] Paiement [   6487,50] Nom complet [          Alan Walsh] NAS [973813265] Salaire [15.0] Heures [32.5] Commission [0.15] Ventes [40000.0]",
                ehc.toStringAffichage());
    }

    @Test
    public void toStringSauvegarde() {
        assertEquals("ID [ 13] Nom complet [          Alan Walsh] NAS [973813265] Taux Horaire [15,00] Heures travaillées [32,50] Taux commission [0,15] Ventes [  40000,00] Mémo [   Du potentiel] Catégorie [EmployeHoraireAvecCommission]",
                ehc.toStringSauvegarde());
    }
}