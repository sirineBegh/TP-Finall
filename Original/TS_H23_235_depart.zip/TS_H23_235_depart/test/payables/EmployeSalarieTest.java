package payables;

import exceptions.ExceptionEcheanceInsuffisante;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class EmployeSalarieTest {
    EmployeSalarie es;

    @Before
    public void setUp() throws Exception {
        es = new EmployeSalarie(10, "Marie Renaud", "246864246", 5000, "Bonne employée");
    }

    @Test
    public void setEcheanceJours() {
        assertEquals(0, es.getEcheanceJours());
        es.setEcheanceJours(10);
        assertEquals(10, es.getEcheanceJours());
        es.setEcheanceJours(0);
        assertEquals(0, es.getEcheanceJours());
    }

    @Test
    public void augmenterEcheance() {
        es.augmenterEcheance(3);
        assertEquals(3, es.getEcheanceJours());
        es.augmenterEcheance(5);
        assertEquals(8, es.getEcheanceJours());
    }

    @Test
    public void diminuerEcheance() throws ExceptionEcheanceInsuffisante {
        es.setEcheanceJours(5);
        es.diminuerEcheance(3);
        assertEquals(2, es.getEcheanceJours());
        es.diminuerEcheance(2);
        assertEquals(0, es.getEcheanceJours());
    }

    @Test(expected = ExceptionEcheanceInsuffisante.class)
    public void diminuerEcheanceException() throws ExceptionEcheanceInsuffisante {
        es.setEcheanceJours(5);
        es.diminuerEcheance(6);
    }

    @Test
    public void setMemo() {
        assertEquals("Bonne employée", es.getMemo());
        es.setMemo("Nouveau mémo");
        assertEquals("Nouveau mémo", es.getMemo());
    }

    @Test
    public void getCategorieString() {
        assertEquals("EmployeSalarie", es.getCategorieString());
    }

    @Test
    public void setSalaireHebdomadaire() {
        assertEquals(5000.0, es.getSalaireHebdomadaire(), 0.001);
        es.setSalaireHebdomadaire(4500.50);
        assertEquals(4500.50, es.getSalaireHebdomadaire(), 0.001);
        es.setSalaireHebdomadaire(0.0);
        assertEquals(0.0, es.getSalaireHebdomadaire(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setSalaireHebdomadaireInvalide() {
        es.setSalaireHebdomadaire(-500.0);
    }

    @Test
    public void getMontantPaiement() {
        assertEquals(5000.0, es.getMontantPaiement(), 0.001);
    }

    @Test
    public void toStringAffichage() {
        assertEquals("ID [ 10] Catégorie [           EmployeSalarie] Mémo [ Bonne employée] Échéance [  0] Paiement [   5000,00] Nom complet [        Marie Renaud] NAS [246864246] Salaire [5000.0]",
                es.toStringAffichage());
    }

    @Test
    public void toStringSauvegarde() {
        assertEquals("ID [ 10] Nom complet [        Marie Renaud] NAS [246864246] Salaire [5000,00] Mémo [ Bonne employée] Catégorie [      EmployeSalarie]",
                es.toStringSauvegarde());
    }
}