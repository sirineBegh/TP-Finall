package payables;

import exceptions.ExceptionEcheanceInsuffisante;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class EmployeHoraireTest {
    EmployeHoraire eh;

    @Before
    public void setUp() throws Exception {
        eh = new EmployeHoraire(11, "Kevin Bouchard", "123321123", 25.50, 35, "Assidu");
    }

    public void setEcheanceJours() {
        assertEquals(0, eh.getEcheanceJours());
        eh.setEcheanceJours(10);
        assertEquals(10, eh.getEcheanceJours());
        eh.setEcheanceJours(0);
        assertEquals(0, eh.getEcheanceJours());
    }

    @Test
    public void augmenterEcheance() {
        eh.augmenterEcheance(3);
        assertEquals(3, eh.getEcheanceJours());
        eh.augmenterEcheance(5);
        assertEquals(8, eh.getEcheanceJours());
    }

    @Test
    public void diminuerEcheance() throws ExceptionEcheanceInsuffisante {
        eh.setEcheanceJours(5);
        eh.diminuerEcheance(3);
        assertEquals(2, eh.getEcheanceJours());
        eh.diminuerEcheance(2);
        assertEquals(0, eh.getEcheanceJours());
    }

    @Test(expected = ExceptionEcheanceInsuffisante.class)
    public void diminuerEcheanceException() throws ExceptionEcheanceInsuffisante {
        eh.setEcheanceJours(5);
        eh.diminuerEcheance(6);
    }

    @Test
    public void setMemo() {
        assertEquals("Assidu", eh.getMemo());
        eh.setMemo("Nouveau mémo");
        assertEquals("Nouveau mémo", eh.getMemo());
    }

    @Test
    public void getCategorieString() {
        assertEquals("EmployeHoraire", eh.getCategorieString());
    }

    @Test
    public void setTauxHoraire() {
        assertEquals(25.50, eh.getTauxHoraire(), 0.001);
        eh.setTauxHoraire(26.00);
        assertEquals(26.00, eh.getTauxHoraire(), 0.001);
        eh.setTauxHoraire(0.0);
        assertEquals(0.0, eh.getTauxHoraire(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setTauxHoraireInvalide() {
        eh.setTauxHoraire(-15.0);
    }

    @Test
    public void setHeuresTravaillees() {
        assertEquals(35.0, eh.getHeuresTravaillees(), 0.001);
        eh.setHeuresTravaillees(15);
        assertEquals(15.0, eh.getHeuresTravaillees(), 0.001);
        eh.setHeuresTravaillees(0.0);
        assertEquals(0.0, eh.getHeuresTravaillees(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setHeuresTravailleesInvalide() {
        eh.setHeuresTravaillees(-5.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setHeuresTravailleesTropGrand() {
        eh.setHeuresTravaillees(170.0);
    }

    @Test
    public void getMontantPaiement() {
        assertEquals(25.5*35, eh.getMontantPaiement(), 0.001);
        eh.setHeuresTravaillees(50.0);
        assertEquals(25.5*40 + 25.5*1.5*10, eh.getMontantPaiement(), 0.001);
        eh.setHeuresTravaillees(0.0);
        assertEquals(0.0, eh.getMontantPaiement(), 0.001);
    }

    @Test
    public void toStringAffichage() {
        assertEquals("ID [ 11] Catégorie [           EmployeHoraire] Mémo [         Assidu] Échéance [  0] Paiement [    892,50] Nom complet [      Kevin Bouchard] NAS [123321123] Salaire [25.5] Heures [35.0]",
                eh.toStringAffichage());
    }

    @Test
    public void toStringSauvegarde() {
        assertEquals("ID [ 11] Nom complet [      Kevin Bouchard] NAS [123321123] Taux Horaire [25,50] Heures travaillées [35,00] Mémo [         Assidu] Catégorie [      EmployeHoraire]",
                eh.toStringSauvegarde());
    }
}