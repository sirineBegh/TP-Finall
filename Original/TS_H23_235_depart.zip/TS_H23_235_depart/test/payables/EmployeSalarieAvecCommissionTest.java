package payables;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class EmployeSalarieAvecCommissionTest {
    EmployeSalarieAvecCommission esc;

    @Before
    public void setUp() throws Exception {
        esc = new EmployeSalarieAvecCommission(12, "Aline Brullemans", "123327832", 4000, 0.1, 15000, "Peu motivée");
    }

    @Test
    public void setTauxCommission() {
        assertEquals(0.1, esc.getTauxCommission(), 0.001);
        esc.setTauxCommission(0.25);
        assertEquals(0.25, esc.getTauxCommission(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setTauxCommissionMinimum() {
        esc.setTauxCommission(0.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setTauxCommissionMaximum() {
        esc.setTauxCommission(1.0);
    }

    @Test
    public void setVentesBrutes() {
        assertEquals(15000, esc.getVentesBrutes(), 0.001);
        esc.setVentesBrutes(18000);
        assertEquals(18000, esc.getVentesBrutes(), 0.001);
        esc.setVentesBrutes(0);
        assertEquals(0, esc.getVentesBrutes(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setVentesBrutesInvalide() {
        esc.setVentesBrutes(-1000);
    }

    @Test
    public void getMontantCommission() {
        assertEquals(0.1 * 12000, esc.getMontantCommission(12000), 0.001);
    }

    @Test
    public void getMontantPaiement() {
        assertEquals(4000 + 0.1*15000, esc.getMontantPaiement(), 0.001);
        esc.setSalaireHebdomadaire(0);
        assertEquals(0.1*15000, esc.getMontantPaiement(), 0.001);
        esc.setVentesBrutes(0);
        assertEquals(0.0, esc.getMontantPaiement(), 0.001);
    }

    @Test
    public void getCategorieString() {
        assertEquals("EmployeSalarieAvecCommission", esc.getCategorieString());
    }

    @Test
    public void toStringAffichage() {
        assertEquals("ID [ 12] Catégorie [EmployeSalarieAvecCommission] Mémo [    Peu motivée] Échéance [  0] Paiement [   5500,00] Nom complet [    Aline Brullemans] NAS [123327832] Salaire [4000.0] Commission [0.1] Ventes [15000.0]",
                esc.toStringAffichage());
    }

    @Test
    public void toStringSauvegarde() {
        assertEquals("ID [ 12] Nom complet [    Aline Brullemans] NAS [123327832] Salaire [4000,00] Taux Commission [0,10] Ventes [  15000,00] Mémo [    Peu motivée] Catégorie [EmployeSalarieAvecCommission]",
                esc.toStringSauvegarde());
    }
}