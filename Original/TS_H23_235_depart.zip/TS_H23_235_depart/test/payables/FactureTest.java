package payables;

import exceptions.ExceptionEcheanceInsuffisante;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class FactureTest {
    Facture f;

    @Before
    public void setUp() throws Exception {
        f = new Facture(14, "34X53", "Tournevis", 34, 23, "Gros vendeur");
    }

    @Test
    public void setEcheanceJours() {
        assertEquals(0, f.getEcheanceJours());
        f.setEcheanceJours(10);
        assertEquals(10, f.getEcheanceJours());
        f.setEcheanceJours(0);
        assertEquals(0, f.getEcheanceJours());
    }

    @Test
    public void augmenterEcheance() {
        f.augmenterEcheance(3);
        assertEquals(3, f.getEcheanceJours());
        f.augmenterEcheance(5);
        assertEquals(8, f.getEcheanceJours());
    }

    @Test
    public void diminuerEcheance() throws ExceptionEcheanceInsuffisante {
        f.setEcheanceJours(5);
        f.diminuerEcheance(3);
        assertEquals(2, f.getEcheanceJours());
        f.diminuerEcheance(2);
        assertEquals(0, f.getEcheanceJours());
    }

    @Test(expected = ExceptionEcheanceInsuffisante.class)
    public void diminuerEcheanceException() throws ExceptionEcheanceInsuffisante {
        f.setEcheanceJours(5);
        f.diminuerEcheance(6);
    }

    @Test
    public void setMemo() {
        assertEquals("Gros vendeur", f.getMemo());
        f.setMemo("Nouveau mémo");
        assertEquals("Nouveau mémo", f.getMemo());
    }

    @Test
    public void getCategorieString() {
        assertEquals("Facture", f.getCategorieString());
    }


    @Test
    public void setDescriptionPiece() {
        assertEquals("Tournevis", f.getDescriptionPiece());
        f.setDescriptionPiece("Tournevis carré");
        assertEquals("Tournevis carré", f.getDescriptionPiece());
    }

    @Test
    public void setQuantite() {
        assertEquals(34, f.getQuantite());
        f.setQuantite(15);
        assertEquals(15, f.getQuantite());
        f.setQuantite(0);
        assertEquals(0, f.getQuantite());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setQuantiteInvalide() {
        f.setQuantite(-1);
    }

    @Test
    public void setPrixParItem() {
        assertEquals(23.0, f.getPrixParItem(), 0.001);
        f.setPrixParItem(17.50);
        assertEquals(17.50, f.getPrixParItem(), 0.001);
        f.setPrixParItem(0.0);
        assertEquals(0.0, f.getPrixParItem(), 0.001);
    }

    @Test
    public void getMontantPaiement() {
        assertEquals(23.0 * 34, f.getMontantPaiement(), 0.001);
        f.setQuantite(0);
        assertEquals(0.0,f.getMontantPaiement(), 0.001);
    }

    @Test
    public void toStringAffichage() {
        assertEquals("ID [ 14] Catégorie [                  Facture] Mémo [   Gros vendeur] Échéance [  0] Paiement [    782,00] Code [34X53] Description [Tournevis] Quantité [34] Prix [23.0]", f.toStringAffichage());
    }

    @Test
    public void toStringSauvegarde() {
        assertEquals("ID [ 14] Numéro [          34X53] Description [                Tournevis] Nombre [ 34] Prix [     23,00] Mémo [   Gros vendeur] Catégorie [             Facture]", f.toStringSauvegarde());
    }
}